package com.example.my_flutter_application_2200016125

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
